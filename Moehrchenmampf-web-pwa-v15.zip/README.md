# Moehrchenmampf

Ein froehliches Snake-aehnliches 2D-Spiel fuer den Browser und spaeter als PWA fuer den Microsoft Store.

## Lokal starten

Am einfachsten startest du im Projektordner einen kleinen lokalen Webserver:

```powershell
python -m http.server 8080
```

Danach im Browser oeffnen:

```text
http://localhost:8080
```

Alternativ kannst du in Visual Studio Code die Erweiterung "Live Server" verwenden und `index.html` damit starten.

## Steuerung

- Pfeiltasten oder WASD
- Auf kleinen Bildschirmen die Richtungstasten unter dem Spielfeld

## Dateien

- `index.html`: Spieloberflaeche
- `styles.css`: Gestaltung
- `game.js`: Spiellogik und Level
- `manifest.json`: PWA-Informationen
- `service-worker.js`: Offline-Cache fuer die PWA
- `assets/icons/icon.svg`: App-Icon

## Microsoft Store

Fuer den Store-Weg:

1. Spiel online mit HTTPS bereitstellen, zum Beispiel ueber GitHub Pages, Netlify, Vercel oder Azure Static Web Apps.
2. Die URL bei <https://www.pwabuilder.com/> eintragen.
3. Windows-Paket erzeugen lassen.
4. Im Microsoft Partner Center einen App-Namen reservieren und das Paket hochladen.

Vor der Einreichung sollten noch PNG-Icons und Store-Screenshots ergaenzt werden.
